package Form;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Form {

public static void main(String[] args) {
	 WebDriver driver = new ChromeDriver();

     try {
         // Open the URL
         driver.get("https://d3pv22lioo8876.cloudfront.net/tiptop/");

         // 1. Verify that the text input element with xpath .//input[@name='my-disabled'] is disabled
         WebElement disabledInput = driver.findElement(By.xpath(".//input[@name='my-disabled']"));
         System.out.println("Disabled Input is disabled: " + !disabledInput.isEnabled());

         // 2. Verify that the text input with value 'Readonly input' is in readonly state by using 2 xpaths
         WebElement readonlyInput1 = driver.findElement(By.xpath(".//input[@value='Readonly input']"));
         WebElement readonlyInput2 = driver.findElement(By.xpath("//input[@readonly]"));
         System.out.println("Readonly Input (XPath 1) is readonly: " +( readonlyInput1.getAttribute("readonly") != null));
         System.out.println("Readonly Input (XPath 2) is readonly: " + (readonlyInput2.getAttribute("readonly") != null));

         // 3. Verify that the dropdown field to select color has 8 elements using 2 xpaths
         WebElement dropdown = driver.findElement(By.xpath("//select[@name='my-select']"));
         Select select = new Select(dropdown);
         List<WebElement> options = select.getOptions();
         System.out.println("Number of elements in dropdown (XPath 1): " + options.size());

         WebElement dropdownAlt = driver.findElement(By.xpath("//select[@class='form-select']"));
         List<WebElement> optionsAlt = new Select(dropdownAlt).getOptions();
         System.out.println("Number of elements in dropdown (XPath 2): " + optionsAlt.size());

         // 4. Verify that the submit button is disabled when no data is entered in Name field
         WebElement submitButton = driver.findElement(By.xpath(".//button[@type='submit']"));
         System.out.println("Submit button is disabled (No data entered): " + !submitButton.isEnabled());

         // 5. Verify that the submit button is enabled when both Name and Password fields are entered
         WebElement nameField = driver.findElement(By.xpath(".//input[@name='my-name']"));
         WebElement passwordField = driver.findElement(By.xpath(".//input[@name='my-password']"));
         nameField.sendKeys("1");
         passwordField.sendKeys(".");
         System.out.println("Submit button is enabled (Data entered): " + submitButton.isEnabled());

         // 6. Verify that on submit of 'Submit' button the page shows 'Received' text
         submitButton.click();
         WebElement receivedText = driver.findElement(By.xpath(".//*[text()='Received!']"));
         System.out.println("Page shows 'Received' text: " + receivedText.isDisplayed());

         // 7. Verify that on submit of form all the data passed to the URL
         String currentUrl = driver.getCurrentUrl();
         System.out.println("Data passed to URL: " + currentUrl);

     } finally {
         // Close the browser
         driver.quit();
     }
}
}
